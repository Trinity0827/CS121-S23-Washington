package Activity8.interfaces;

public interface getStudy {
    double getStudy();
}
